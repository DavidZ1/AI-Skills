---
name: bigdata-optimization-agent
label: 大数据组件调优智能体
description: "大数据组件优化方案自动收集、分类和报告生成技能。用于每天自动搜索、收集、整理和报告大数据组件的性能优化、配置调优、最佳实践等技术方案。当用户需要：1) 获取Apache Spark、Apache Flink、Apache Paimon、Apache Hive、Apache Kafka、Apache Fluss等大数据组件的优化方案，2) 收集组件调优的最佳实践和性能提升手段，3) 生成包含原始链接和详细建议的优化报告，4) 自动化跟踪技术优化趋势，5) 获取学习资源和深入研究的参考资料时使用此技能。"
---

# 大数据组件调优智能体

## 概述

本技能提供大数据组件优化方案的自动化收集、分类、分析和报告生成能力。通过智能搜索、组件分类和优化方案整理，帮助用户持续跟踪大数据技术的最佳实践和性能优化手段。

## 核心工作流程

### 1. 需求分析阶段
- 确认用户需要大数据组件优化报告
- 确定关注的组件范围（Spark、Flink、Paimon、Hive、Kafka、Fluss等）
- 设置报告格式和输出要求
- 确认优化类型偏好（性能调优、配置优化、架构优化等）

### 2. 数据收集阶段
**搜索策略**：
- 使用`web_search`工具进行多轮优化方案搜索
- 每轮最多3个查询，避免重复
- 专门搜索"optimization"、"tuning"、"best practices"、"performance"等关键词

**组件覆盖**：
- **计算引擎**：Apache Spark、Apache Flink
- **存储组件**：Apache Paimon、Apache Hive
- **消息队列**：Apache Kafka
- **流处理**：Apache Fluss
- **其他相关**：Trino/Presto、ClickHouse、Doris等

**搜索重点**：
- 性能优化方案
- 配置参数调优
- 架构设计最佳实践
- 故障排查技巧
- 资源利用率提升

### 3. 内容处理阶段
**分类标准**：
- **组件分类**：Spark、Flink、Paimon、Hive、Kafka、Fluss等
- **优化类型**：性能调优、配置优化、架构优化、故障排除
- **内容形式**：官方文档、技术博客、案例研究、教程指南
- **重要性等级**：高（核心优化）、中（实用技巧）、低（参考信息）

**质量筛选**：
- 优先官方文档和技术博客
- 确保原始链接可访问且权威
- 排除营销内容和重复信息
- 验证技术方案的时效性

### 4. 报告生成阶段
**报告结构**：
1. 今日优化亮点（2-3条最重要的优化方案）
2. 按组件分类的优化方案
3. 通用优化最佳实践
4. 案例研究和实际应用
5. 学习资源和深入阅读

**格式化要求**：
- 使用统一的Markdown格式
- 每个优化方案包含：问题描述、优化方案、实施步骤、预期效果
- 每个条目必须包含原始链接
- 标注组件类型、优化类别和重要性等级
- 提供统计信息和明日预告

## 详细操作指南

### 搜索查询构建
参考 [search_strategies.md](references/search_strategies.md) 获取完整的搜索策略和查询模板。

**关键原则**：
1. **组件特定搜索**：针对每个组件单独搜索优化方案
2. **优化类型区分**：性能优化、配置调优、架构设计分开搜索
3. **时间限定**：优先最近1-3个月的内容，重要方案可扩展到6个月
4. **来源优先级**：官方文档 > 技术社区 > 企业博客 > 个人博客

**示例查询组合**：
```python
# 第一轮：核心组件性能优化
["Apache Spark performance optimization 2025", "Flink streaming tuning best practices", "Kafka throughput optimization techniques"]

# 第二轮：配置调优和架构设计  
["Paimon table optimization configuration", "Hive query performance tuning", "data warehouse optimization patterns"]

# 第三轮：案例研究和故障排除
["Spark memory optimization case study", "Flink checkpoint tuning real-world", "Kafka consumer lag troubleshooting"]
```

### 内容分类处理
参考 [components_reference.md](references/components_reference.md) 了解完整组件信息和优化分类。

**分类逻辑**：
1. **组件识别**：通过关键词匹配确定组件归属
2. **优化类型判断**：根据内容特征区分性能优化、配置调优等
3. **重要性评估**：基于优化效果和适用范围评级
4. **实施难度评估**：简单（配置调整）、中等（代码修改）、复杂（架构重构）

**处理要点**：
- 提取具体的优化参数和配置值
- 记录优化前后的性能对比数据
- 标注适用的场景和前提条件
- 识别潜在的风险和注意事项

### 报告格式化
参考 [report_template.md](references/report_template.md) 获取完整的报告模板和示例。

**格式化要点**：
1. **标题规范**：`大数据组件优化日报 - YYYY年MM月DD日`
2. **组件标签**：统一使用 `[Spark]`、`[Flink]`、`[Paimon]` 等标签
3. **优化类型标签**：使用 `[性能优化]`、`[配置调优]`、`[架构设计]` 等标签
4. **链接格式**：`[文章标题](完整URL)`
5. **重要性标识**：⭐（高）、🔶（中）、◯（低）

**内容结构**：
- 问题描述：简要说明需要优化的场景或问题
- 优化方案：具体的优化手段和实施方法
- 实施步骤：详细的操作步骤或配置修改
- 预期效果：优化后的性能提升或问题解决效果
- 注意事项：实施过程中需要注意的事项

## 执行示例

### 完整工作流程示例

```python
# 1. 初始化组件
query_gen = OptimizationQueryGenerator()
processor = OptimizationProcessor()
report_gen = OptimizationReportGenerator()

# 2. 生成搜索查询
queries = query_gen.generate_daily_optimization_queries()

# 3. 执行搜索（使用web_search工具）
search_results = []
for query_set in queries:
    results = web_search(query_set)
    search_results.extend(results)

# 4. 处理和分析优化内容
optimization_items = []
for result in search_results:
    analysis = processor.analyze_optimization(
        result.title,
        result.content,
        result.url
    )
    
    item = {
        'title': result.title,
        'summary': analysis['summary'],
        'url': result.url,
        'component': analysis['component'],
        'optimization_type': analysis['type'],
        'difficulty': analysis['difficulty'],
        'expected_improvement': analysis['improvement'],
        'date': processor.extract_date(result.content),
        'importance': analysis['importance']
    }
    optimization_items.append(item)

# 5. 生成优化报告
report = report_gen.generate_optimization_report(optimization_items)

# 6. 输出报告
save_report(report, f"bigdata-optimization-daily-{date}.md")
```

### 用户交互示例

**用户请求**：
"请给我今天的大数据组件优化报告"

**执行步骤**：
1. 确认需求：优化方案报告，涵盖指定组件范围
2. 执行3轮搜索（性能优化、配置调优、案例研究）
3. 处理搜索结果，按组件和优化类型分类
4. 提取具体的优化参数和实施方法
5. 生成格式化报告，包含原始链接和实施建议

**输出格式**：
- 飞书云文档（如果用户需要）
- Markdown文件（本地保存）
- 控制台预览（简要展示）

## 资源文件说明

### references/ 目录
- **components_reference.md**：完整的组件参考信息，包括各组件官方文档链接、常见优化场景和配置参数
- **search_strategies.md**：搜索策略和查询模板，提供针对优化方案的详细搜索指导
- **report_template.md**：报告模板和格式化规范，确保输出一致性
- **optimization_categories.md**：优化分类体系和评估标准

### scripts/ 目录
- **optimization_processor.py**：核心处理脚本，包含查询生成、内容分析、报告生成等功能

### assets/ 目录
（可根据需要添加模板文件、图标等资源）

## 质量保证

### 内容质量标准
1. **准确性**：确保优化方案技术准确，参数配置正确
2. **实用性**：提供可实施的优化步骤和具体配置
3. **时效性**：优先最近3个月内容，标注明确时间
4. **完整性**：包含问题描述、方案、步骤、效果、注意事项
5. **权威性**：优先官方文档和技术专家博客

### 格式一致性标准
1. **结构统一**：遵循标准报告结构
2. **标记规范**：使用统一的组件标签和优化类型标签
3. **链接完整**：每个优化方案都有可访问的原始链接
4. **参数明确**：具体的配置参数和优化值清晰标注
5. **统计清晰**：提供明确的分类统计信息

## 常见问题处理

### 搜索结果不足
- 扩大时间范围到6个月
- 增加相关组件和优化类型关键词
- 尝试英文搜索（国际技术社区）
- 搜索特定版本号的优化方案

### 内容分类困难
- 参考components_reference.md中的关键词
- 使用OptimizationProcessor的自动化分类
- 人工复核重要优化方案
- 咨询技术专家或参考官方文档

### 技术方案验证
- 交叉验证多个来源的相同优化方案
- 检查方案是否适用于当前主流版本
- 验证配置参数的有效性和安全性
- 评估实施难度和风险

## 扩展和定制

### 组件扩展
如需增加新的组件覆盖：
1. 在components_reference.md中添加组件信息
2. 更新search_strategies.md中的搜索关键词
3. 修改OptimizationProcessor的分类逻辑
4. 添加组件的常见优化场景和参数

### 优化类型扩展
如需增加新的优化类别：
1. 在optimization_categories.md中定义新类别
2. 更新搜索策略和查询模板
3. 调整报告模板中的分类结构
4. 添加相应的评估标准和标签

### 自动化增强
如需完全自动化：
1. 设置定时任务调用脚本
2. 集成到CI/CD流水线中自动执行
3. 添加异常处理和监控告警
4. 建立优化方案知识库和历史记录

### 报告格式定制
如需调整报告格式：
1. 修改report_template.md中的模板
2. 更新OptimizationReportGenerator的生成逻辑
3. 保持核心结构不变以确保可用性
4. 添加用户特定的格式要求

---

**使用提示**：本技能专注于大数据组件的优化方案收集和报告生成。建议先阅读references目录下的文件了解完整规范，再根据实际需求调整工作流程。对于复杂的优化方案，建议结合官方文档进行深入验证。

**重要提醒**：优化方案实施前，请在测试环境中验证效果，确保方案适用于您的具体场景和版本。