#!/usr/bin/env python3
"""
大数据问题处理脚本
用于分析、分类和处理收集到的大数据领域问题
"""

import re
import json
from datetime import datetime
from typing import Dict, List, Any, Optional
from dataclasses import dataclass, asdict


@dataclass
class BigDataQuestion:
    """大数据问题数据结构"""
    title: str
    description: str
    url: str
    components: List[str]  # 涉及的组件
    question_type: str     # 问题类型
    difficulty: str        # 难度等级
    source: str           # 来源网站
    key_points: List[str] # 关键要点
    solution_hints: str   # 解决方案思路
    related_links: List[Dict[str, str]]  # 相关链接
    collected_date: str   # 收集日期
    importance: int       # 重要性评分 1-5
    
    def to_dict(self) -> Dict[str, Any]:
        """转换为字典"""
        return asdict(self)
    
    def to_markdown(self) -> str:
        """转换为Markdown格式"""
        md = f"### {self.title}\n\n"
        md += f"**组件**: {', '.join([f'[{c}]' for c in self.components])}\n\n"
        md += f"**类型**: [{self.question_type}]  "
        md += f"**难度**: {'⭐' * int(self.difficulty.replace('⭐', ''))}  "
        md += f"**来源**: {self.source}\n\n"
        md += f"**问题描述**:\n{self.description}\n\n"
        
        if self.key_points:
            md += "**核心要点**:\n"
            for point in self.key_points:
                md += f"- {point}\n"
            md += "\n"
        
        if self.solution_hints:
            md += f"**解决方案思路**:\n{self.solution_hints}\n\n"
        
        if self.related_links:
            md += "**深入学习资源**:\n"
            for link in self.related_links:
                md += f"- [{link['title']}]({link['url']})\n"
        
        return md


class QuestionProcessor:
    """问题处理器"""
    
    # 组件关键词映射
    COMPONENT_KEYWORDS = {
        'Spark': ['spark', 'rdd', 'dataframe', 'spark sql', 'catalyst'],
        'Flink': ['flink', 'datastream', 'table api', 'state', 'checkpoint'],
        'Kafka': ['kafka', 'producer', 'consumer', 'broker', 'partition'],
        'Hive': ['hive', 'hql', 'metastore', 'partition', 'tez'],
        'Paimon': ['paimon', 'lakehouse', 'cdc', 'merge-on-read'],
        'Fluss': ['fluss', 'streaming', 'event time', 'processing time']
    }
    
    # 问题类型关键词
    QUESTION_TYPE_KEYWORDS = {
        'SQL优化': ['sql', '查询', '优化', 'join', '索引', '分区'],
        '组件原理': ['原理', '机制', '实现', '源码', '底层', '架构'],
        '场景优化': ['场景', '案例', '实战', '性能', '调优', '故障'],
        '面试题': ['面试', '题目', '考题', '面经', '求职', '招聘'],
        '故障排查': ['故障', '排查', '诊断', '错误', '异常', '问题解决'],
        '系统设计': ['设计', '架构', '系统', '方案', '规划', '设计模式']
    }
    
    # 难度关键词
    DIFFICULTY_KEYWORDS = {
        '⭐': ['基础', '入门', '简单', '基本', '初级', '新手'],
        '⭐⭐': ['中级', '实践', '应用', '实战', '优化', '调优'],
        '⭐⭐⭐': ['高级', '深度', '原理', '源码', '架构', '专家']
    }
    
    def __init__(self):
        self.questions: List[BigDataQuestion] = []
    
    def analyze_content(self, title: str, content: str, url: str, source: str) -> Dict[str, Any]:
        """分析内容并提取问题信息"""
        
        # 识别组件
        components = self._identify_components(title + " " + content)
        
        # 识别问题类型
        question_type = self._identify_question_type(title + " " + content)
        
        # 识别难度
        difficulty = self._identify_difficulty(title + " " + content)
        
        # 提取关键要点
        key_points = self._extract_key_points(content)
        
        # 提取解决方案思路
        solution_hints = self._extract_solution_hints(content)
        
        # 生成重要性评分
        importance = self._calculate_importance(components, question_type, difficulty)
        
        return {
            'title': title,
            'description': self._generate_description(content),
            'url': url,
            'components': components,
            'question_type': question_type,
            'difficulty': difficulty,
            'source': source,
            'key_points': key_points,
            'solution_hints': solution_hints,
            'related_links': [{'title': '原始文章', 'url': url}],
            'collected_date': datetime.now().strftime('%Y-%m-%d'),
            'importance': importance
        }
    
    def _identify_components(self, text: str) -> List[str]:
        """识别文本中涉及的大数据组件"""
        text_lower = text.lower()
        components = []
        
        for component, keywords in self.COMPONENT_KEYWORDS.items():
            for keyword in keywords:
                if keyword in text_lower:
                    components.append(component)
                    break
        
        # 去重
        return list(set(components))
    
    def _identify_question_type(self, text: str) -> str:
        """识别问题类型"""
        text_lower = text.lower()
        
        for qtype, keywords in self.QUESTION_TYPE_KEYWORDS.items():
            for keyword in keywords:
                if keyword in text_lower:
                    return qtype
        
        # 默认类型
        return '通用问题'
    
    def _identify_difficulty(self, text: str) -> str:
        """识别难度等级"""
        text_lower = text.lower()
        
        for difficulty, keywords in self.DIFFICULTY_KEYWORDS.items():
            for keyword in keywords:
                if keyword in text_lower:
                    return difficulty
        
        # 默认难度
        return '⭐⭐'
    
    def _extract_key_points(self, content: str) -> List[str]:
        """从内容中提取关键要点"""
        key_points = []
        
        # 查找列表项
        list_patterns = [
            r'[-•*]\s*(.+?)(?=\n[-•*]|\n\n|$)',
            r'\d+[\.、]\s*(.+?)(?=\n\d+[\.、]|\n\n|$)'
        ]
        
        for pattern in list_patterns:
            matches = re.findall(pattern, content, re.DOTALL)
            for match in matches:
                point = match.strip()
                if len(point) > 10 and len(point) < 200:  # 合理的长度范围
                    key_points.append(point)
        
        # 限制数量
        return key_points[:5]
    
    def _extract_solution_hints(self, content: str) -> str:
        """提取解决方案思路"""
        # 查找解决方案相关的段落
        solution_keywords = ['解决', '方案', '方法', '步骤', '优化', '建议', '技巧']
        paragraphs = content.split('\n\n')
        
        for para in paragraphs:
            para_lower = para.lower()
            if any(keyword in para_lower for keyword in solution_keywords):
                # 截取适当长度
                if len(para) > 500:
                    para = para[:497] + "..."
                return para
        
        return "暂无详细解决方案，请参考原始文章。"
    
    def _generate_description(self, content: str) -> str:
        """生成问题描述"""
        # 提取前两段作为描述
        paragraphs = [p.strip() for p in content.split('\n\n') if p.strip()]
        
        if not paragraphs:
            return "问题描述待补充。"
        
        description = paragraphs[0]
        if len(paragraphs) > 1 and len(description) < 100:
            description += " " + paragraphs[1]
        
        # 限制长度
        if len(description) > 300:
            description = description[:297] + "..."
        
        return description
    
    def _calculate_importance(self, components: List[str], question_type: str, difficulty: str) -> int:
        """计算重要性评分"""
        score = 3  # 基础分
        
        # 组件权重
        core_components = ['Spark', 'Flink', 'Kafka']
        if any(comp in core_components for comp in components):
            score += 1
        
        # 问题类型权重
        important_types = ['SQL优化', '场景优化', '面试题']
        if question_type in important_types:
            score += 1
        
        # 难度权重
        if difficulty == '⭐⭐⭐':
            score += 1
        
        return min(max(score, 1), 5)  # 限制在1-5分
    
    def add_question(self, question_data: Dict[str, Any]) -> None:
        """添加问题到列表"""
        question = BigDataQuestion(**question_data)
        self.questions.append(question)
    
    def get_statistics(self) -> Dict[str, Any]:
        """获取统计信息"""
        if not self.questions:
            return {}
        
        stats = {
            'total_questions': len(self.questions),
            'components_distribution': {},
            'types_distribution': {},
            'difficulty_distribution': {},
            'importance_distribution': {}
        }
        
        # 组件分布
        for question in self.questions:
            for component in question.components:
                stats['components_distribution'][component] = stats['components_distribution'].get(component, 0) + 1
        
        # 类型分布
        for question in self.questions:
            qtype = question.question_type
            stats['types_distribution'][qtype] = stats['types_distribution'].get(qtype, 0) + 1
        
        # 难度分布
        for question in self.questions:
            difficulty = question.difficulty
            stats['difficulty_distribution'][difficulty] = stats['difficulty_distribution'].get(difficulty, 0) + 1
        
        # 重要性分布
        for question in self.questions:
            importance = question.importance
            stats['importance_distribution'][importance] = stats['importance_distribution'].get(importance, 0) + 1
        
        return stats
    
    def generate_report(self, template: str) -> str:
        """生成报告"""
        # 这里可以扩展为使用模板引擎
        # 目前返回简单格式
        report = "# 大数据问题收集报告\n\n"
        
        stats = self.get_statistics()
        if stats:
            report += "## 统计概览\n\n"
            report += f"- 问题总数: {stats['total_questions']} 个\n"
            
            if stats['components_distribution']:
                report += "- 组件分布:\n"
                for comp, count in stats['components_distribution'].items():
                    report += f"  - {comp}: {count} 个\n"
        
        report += "\n## 问题列表\n\n"
        for i, question in enumerate(self.questions, 1):
            report += f"### {i}. {question.title}\n"
            report += f"组件: {', '.join(question.components)}\n"
            report += f"类型: {question.question_type} | 难度: {question.difficulty}\n"
            report += f"来源: {question.source}\n\n"
            report += f"{question.description[:200]}...\n\n"
            report += f"[阅读原文]({question.url})\n\n"
            report += "---\n\n"
        
        return report
    
    def save_to_json(self, filepath: str) -> None:
        """保存为JSON文件"""
        data = {
            'questions': [q.to_dict() for q in self.questions],
            'statistics': self.get_statistics(),
            'generated_at': datetime.now().isoformat()
        }
        
        with open(filepath, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
    
    def load_from_json(self, filepath: str) -> None:
        """从JSON文件加载"""
        with open(filepath, 'r', encoding='utf-8') as f:
            data = json.load(f)
        
        self.questions = [BigDataQuestion(**q) for q in data['questions']]


def main():
    """测试主函数"""
    processor = QuestionProcessor()
    
    # 测试数据
    test_data = {
        'title': 'Spark SQL查询数据倾斜优化',
        'content': '''
        在大数据量的Join操作中，经常遇到数据倾斜问题。某个key的数据量远大于其他key，导致单个task处理时间过长。
        
        解决方案：
        1. 使用随机前缀打散大key
        2. 过滤异常值或null值
        3. 调整shuffle分区数
        4. 使用广播Join替代Shuffle Join
        
        关键要点：
        - 数据倾斜的常见原因
        - 倾斜检测方法
        - 多种优化方案选择
        ''',
        'url': 'https://example.com/spark-data-skew',
        'source': '阿里云技术博客'
    }
    
    # 分析内容
    analysis = processor.analyze_content(
        test_data['title'],
        test_data['content'],
        test_data['url'],
        test_data['source']
    )
    
    print("分析结果:")
    print(json.dumps(analysis, ensure_ascii=False, indent=2))
    
    # 添加问题
    processor.add_question(analysis)
    
    # 生成报告
    report = processor.generate_report("")
    print("\n生成报告:")
    print(report[:500] + "...")
    
    # 获取统计
    stats = processor.get_statistics()
    print("\n统计信息:")
    print(json.dumps(stats, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()