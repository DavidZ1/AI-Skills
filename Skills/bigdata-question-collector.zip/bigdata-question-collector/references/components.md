# 大数据组件参考信息

## 组件分类和关键词

### 计算引擎
- **Apache Spark**: Spark, RDD, DataFrame, Spark SQL, Catalyst Optimizer, Tungsten, Shuffle, Broadcast, Partition, Checkpoint
- **Apache Flink**: Flink, DataStream, Table API, State, Checkpoint, Watermark, Window, Exactly-Once, Two-Phase Commit

### 存储组件
- **Apache Paimon**: Paimon, Lakehouse, CDC, Merge-On-Read, Primary Key, Bucket, Snapshot
- **Apache Hive**: Hive, HQL, Metastore, Partition, Bucket, Tez, ORC, Parquet

### 消息队列
- **Apache Kafka**: Kafka, Producer, Consumer, Broker, Partition, Replica, ISR, Offset, Consumer Group, Exactly-Once

### 流处理
- **Apache Fluss**: Fluss, Streaming, Event Time, Processing Time, Stateful Processing

## 问题类型分类

### SQL优化类
- 查询性能优化
- 索引设计和使用
- 分区策略
- 数据倾斜处理
- Join优化
- 聚合优化

### 组件实现类
- 算子实现原理
- 内存管理机制
- 调度算法
- 容错机制
- 数据一致性保证

### 场景优化类
- 大数据量处理优化
- 实时流处理优化
- 批处理优化
- 混合负载优化
- 资源利用率优化

### 面试题类
- 经典面试问题
- 系统设计问题
- 故障排查问题
- 性能调优问题
- 架构设计问题

## 难度等级定义

### ⭐ 初级（基础理解）
- 基本概念和原理
- 常用配置参数
- 简单使用场景
- 基础优化技巧

### ⭐⭐ 中级（实践应用）
- 复杂场景处理
- 性能调优实践
- 故障排查分析
- 系统设计思考

### ⭐⭐⭐ 高级（深度原理）
- 源码级理解
- 底层机制分析
- 架构设计优化
- 前沿技术探索

## 搜索关键词模板

### 问题收集关键词
- "常见问题" "经典问题" "面试题" "难题" "挑战"
- "优化场景" "性能问题" "故障排查" "疑难杂症"
- "实现原理" "工作机制" "底层原理" "源码分析"

### 组件特定关键词
- Spark: "Spark常见问题" "Spark面试题" "Spark性能优化"
- Flink: "Flink常见问题" "Flink面试题" "Flink状态管理"
- Kafka: "Kafka常见问题" "Kafka面试题" "Kafka消费延迟"
- Hive: "Hive常见问题" "Hive面试题" "Hive查询优化"
- Paimon: "Paimon常见问题" "Paimon最佳实践" "Paimon性能调优"

### 组合搜索模式
- "[组件名] 常见问题 2025"
- "[组件名] 面试题 高级"
- "[组件名] 性能优化 案例"
- "[组件名] 实现原理 源码"

## 权威来源优先级

1. **官方文档**: Apache官网、GitHub仓库、官方博客
2. **技术社区**: Stack Overflow、GitHub Issues、技术论坛
3. **企业博客**: 阿里云、腾讯云、AWS、Google等技术博客
4. **个人技术博客**: 知名技术专家的个人博客
5. **技术会议**: ApacheCon、Flink Forward、Spark Summit等会议资料

## 内容质量评估标准

### 高质量内容特征
- 问题描述清晰具体
- 解决方案完整可行
- 包含实际案例或数据
- 有深入的技术分析
- 提供进一步学习资源

### 低质量内容特征
- 问题描述模糊笼统
- 解决方案不完整
- 缺乏实际案例支撑
- 内容过时或版本不匹配
- 营销性质过重

## 时间范围建议

- **近期内容**（1-3个月）：优先选择，确保时效性
- **经典内容**（3-12个月）：重要问题可适当放宽
- **历史内容**（1年以上）：仅限经典、原理性内容

## 语言偏好
- 中文内容优先
- 英文高质量内容可适当收录
- 混合语言内容需确保关键信息可读