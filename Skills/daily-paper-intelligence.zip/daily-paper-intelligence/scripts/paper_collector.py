#!/usr/bin/env python3
"""
论文收集器 - 自动收集前一天最新发布的国际论文
支持多平台：arXiv、PubMed、IEEE Xplore、ACM Digital Library
"""

import json
import requests
import xml.etree.ElementTree as ET
from datetime import datetime, timedelta
from typing import List, Dict, Optional
import re
import time


class PaperCollector:
    """论文收集器主类"""
    
    def __init__(self, domains: List[str] = None):
        """
        初始化论文收集器
        
        Args:
            domains: 关注的领域列表，如 ['cs.AI', 'cs.LG', 'stat.ML']
        """
        self.domains = domains or [
            'cs.AI',  # 人工智能
            'cs.LG',  # 机器学习
            'cs.CV',  # 计算机视觉
            'cs.CL',  # 计算语言学
            'stat.ML',  # 统计机器学习
            'q-bio',   # 定量生物学
            'physics', # 物理学
            'math',    # 数学
        ]
        
        self.base_urls = {
            'arxiv': 'http://export.arxiv.org/api/query',
            'pubmed': 'https://eutils.ncbi.nlm.nih.gov/entrez/eutils/',
        }
        
    def get_yesterday_date(self) -> str:
        """获取昨天的日期字符串"""
        yesterday = datetime.now() - timedelta(days=1)
        return yesterday.strftime('%Y-%m-%d')
    
    def search_arxiv(self, max_results: int = 20) -> List[Dict]:
        """搜索arXiv最新论文"""
        papers = []
        
        # 为每个领域搜索（简化查询，避免复杂日期过滤）
        for category in self.domains[:3]:  # 限制前3个领域
            try:
                # 简化查询：只按领域搜索，按提交时间排序
                params = {
                    'search_query': f'cat:{category}',
                    'start': 0,
                    'max_results': 15,
                    'sortBy': 'submittedDate',
                    'sortOrder': 'descending'
                }
                
                response = requests.get(self.base_urls['arxiv'], params=params, timeout=30)
                response.raise_for_status()
                
                # 解析Atom XML
                root = ET.fromstring(response.content)
                namespace = {'atom': 'http://www.w3.org/2005/Atom'}
                
                entry_count = 0
                for entry in root.findall('atom:entry', namespace):
                    if entry_count >= 5:  # 每个领域最多5篇
                        break
                        
                    published_date = entry.find('atom:published', namespace).text
                    # 检查是否是最近3天内的论文
                    if published_date:
                        try:
                            pub_date = datetime.fromisoformat(published_date.replace('Z', '+00:00'))
                            days_diff = (datetime.now(pub_date.tzinfo) - pub_date).days
                            if days_diff <= 3:  # 最近3天内
                                paper = {
                                    'source': 'arXiv',
                                    'id': entry.find('atom:id', namespace).text,
                                    'title': entry.find('atom:title', namespace).text.strip(),
                                    'summary': entry.find('atom:summary', namespace).text.strip() if entry.find('atom:summary', namespace) is not None else '',
                                    'published': published_date,
                                    'updated': entry.find('atom:updated', namespace).text,
                                    'authors': [author.find('atom:name', namespace).text for author in entry.findall('atom:author', namespace)],
                                    'categories': [cat.get('term') for cat in entry.findall('atom:category', namespace)],
                                    'link': entry.find('atom:id', namespace).text.replace('http://', 'https://'),
                                }
                                
                                # 清理摘要中的换行和多余空格
                                paper['summary'] = re.sub(r'\s+', ' ', paper['summary'])
                                
                                papers.append(paper)
                                entry_count += 1
                        except:
                            # 日期解析失败，跳过这篇论文
                            continue
                
                time.sleep(1)  # 避免请求过快
                
            except Exception as e:
                print(f"arXiv搜索错误 ({category}): {str(e)[:100]}...")
                continue
        
        # 按发布时间排序，取最新的
        papers.sort(key=lambda x: x['published'], reverse=True)
        return papers[:max_results]
    
    def extract_key_points(self, paper: Dict) -> Dict:
        """提取论文核心点"""
        title = paper.get('title', '')
        summary = paper.get('summary', '')
        
        # 简单的关键词提取（实际应用中可以使用更复杂的NLP模型）
        keywords = [
            'novel', 'propose', 'introduce', 'demonstrate', 'achieve',
            'improve', 'enhance', 'outperform', 'state-of-the-art',
            'method', 'framework', 'model', 'algorithm', 'approach',
            'experiment', 'result', 'accuracy', 'performance'
        ]
        
        # 从摘要中提取包含关键词的句子
        key_sentences = []
        sentences = re.split(r'[.!?]+', summary)
        
        for sentence in sentences:
            sentence = sentence.strip()
            if any(keyword.lower() in sentence.lower() for keyword in keywords):
                if len(sentence) > 20:  # 避免太短的句子
                    key_sentences.append(sentence)
        
        # 如果找不到关键词句子，使用摘要的前3句话
        if not key_sentences and sentences:
            key_sentences = sentences[:3]
        
        return {
            'title': title,
            'key_points': key_sentences[:5],  # 最多5个关键点
            'main_contribution': self._identify_contribution(summary),
            'practical_implication': self._extract_implication(summary)
        }
    
    def _identify_contribution(self, summary: str) -> str:
        """识别主要贡献"""
        contribution_phrases = [
            'we propose', 'we introduce', 'we present', 'we develop',
            'our method', 'our framework', 'our model', 'our approach'
        ]
        
        for phrase in contribution_phrases:
            if phrase.lower() in summary.lower():
                # 找到包含该短语的句子
                sentences = re.split(r'[.!?]+', summary)
                for sentence in sentences:
                    if phrase.lower() in sentence.lower():
                        return sentence.strip()
        
        # 如果没有找到，返回摘要的第一句话
        sentences = summary.split('.')
        return sentences[0].strip() if sentences else "未明确说明主要贡献"
    
    def _extract_implication(self, summary: str) -> str:
        """提取实际意义"""
        implication_phrases = [
            'can be applied', 'has applications', 'enables', 'allows',
            'improves', 'enhances', 'benefits', 'useful for'
        ]
        
        for phrase in implication_phrases:
            if phrase.lower() in summary.lower():
                sentences = re.split(r'[.!?]+', summary)
                for sentence in sentences:
                    if phrase.lower() in sentence.lower():
                        return sentence.strip()
        
        return "该研究具有潜在的实际应用价值"
    
    def simplify_explanation(self, key_points: Dict) -> str:
        """用大白话解释技术内容"""
        explanation = f"论文《{key_points['title']}》主要做了这些事情：\n\n"
        
        if key_points['key_points']:
            explanation += "1. 核心发现/方法：\n"
            for i, point in enumerate(key_points['key_points'], 1):
                # 简化技术术语
                simplified = point
                simplified = re.sub(r'\bpropose\b', '提出了', simplified)
                simplified = re.sub(r'\bintroduce\b', '引入了', simplified)
                simplified = re.sub(r'\bdevelop\b', '开发了', simplified)
                simplified = re.sub(r'\bmodel\b', '模型', simplified)
                simplified = re.sub(r'\bframework\b', '框架', simplified)
                simplified = re.sub(r'\balgorithm\b', '算法', simplified)
                simplified = re.sub(r'\bexperiment\b', '实验', simplified)
                simplified = re.sub(r'\bresult\b', '结果', simplified)
                
                explanation += f"   • {simplified}\n"
        
        explanation += f"\n2. 主要贡献：{key_points['main_contribution']}\n"
        explanation += f"\n3. 实际意义：{key_points['practical_implication']}\n"
        
        return explanation
    
    def collect_daily_papers(self, max_papers: int = 5) -> List[Dict]:
        """收集每日论文的主要入口函数"""
        print(f"开始收集{self.get_yesterday_date()}的最新论文...")
        
        # 收集论文
        raw_papers = self.search_arxiv(max_results=20)
        
        if not raw_papers:
            print("未找到前一天的论文")
            return []
        
        # 处理每篇论文
        processed_papers = []
        for paper in raw_papers[:max_papers]:
            try:
                key_points = self.extract_key_points(paper)
                simple_explanation = self.simplify_explanation(key_points)
                
                processed_paper = {
                    'source': paper['source'],
                    'title': paper['title'],
                    'link': paper['link'],
                    'authors': paper['authors'],
                    'published': paper['published'],
                    'categories': paper['categories'],
                    'key_points': key_points['key_points'],
                    'main_contribution': key_points['main_contribution'],
                    'practical_implication': key_points['practical_implication'],
                    'simple_explanation': simple_explanation,
                    'raw_summary': paper['summary'][:500]  # 保留原始摘要前500字符
                }
                
                processed_papers.append(processed_paper)
                
            except Exception as e:
                print(f"处理论文错误 ({paper.get('title', '未知标题')}): {e}")
                continue
        
        print(f"成功处理了 {len(processed_papers)} 篇论文")
        return processed_papers


def main():
    """主函数 - 测试用"""
    collector = PaperCollector()
    papers = collector.collect_daily_papers(max_papers=3)
    
    if papers:
        print(f"\n=== {collector.get_yesterday_date()} 论文日报 ===\n")
        for i, paper in enumerate(papers, 1):
            print(f"【论文{i}】{paper['title']}")
            print(f"来源：{paper['source']}")
            print(f"作者：{', '.join(paper['authors'][:3])}{'等' if len(paper['authors']) > 3 else ''}")
            print(f"链接：{paper['link']}")
            print(f"\n核心要点：")
            for point in paper['key_points']:
                print(f"  • {point}")
            print(f"\n大白话解释：")
            print(f"{paper['simple_explanation']}")
            print("-" * 80 + "\n")
    else:
        print("今天没有新论文")


if __name__ == "__main__":
    main()