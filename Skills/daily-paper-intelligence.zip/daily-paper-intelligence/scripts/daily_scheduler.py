#!/usr/bin/env python3
"""
每日论文推送调度器 - 自动在每天9点收集论文并生成报告
"""

import os
import sys
import json
import schedule
import time
from datetime import datetime
from pathlib import Path
import subprocess


class PaperDailyScheduler:
    """论文日报调度器"""
    
    def __init__(self, output_dir: str = "./output"):
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(exist_ok=True)
        
        # 设置日志文件
        self.log_file = self.output_dir / "scheduler.log"
        
    def log_message(self, message: str):
        """记录日志"""
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        log_entry = f"[{timestamp}] {message}\n"
        
        print(log_entry.strip())
        with open(self.log_file, 'a', encoding='utf-8') as f:
            f.write(log_entry)
    
    def run_daily_collection(self):
        """执行每日论文收集任务"""
        try:
            self.log_message("开始执行每日论文收集任务...")
            
            # 运行论文收集器
            script_path = Path(__file__).parent / "paper_collector.py"
            
            # 使用子进程运行收集器
            result = subprocess.run(
                [sys.executable, str(script_path)],
                capture_output=True,
                text=True,
                encoding='utf-8'
            )
            
            if result.returncode == 0:
                self.log_message("论文收集成功")
                # 这里可以添加生成飞书文档或Markdown文件的逻辑
                self.generate_report(result.stdout)
            else:
                self.log_message(f"论文收集失败: {result.stderr}")
                
        except Exception as e:
            self.log_message(f"任务执行异常: {e}")
    
    def generate_report(self, paper_data: str):
        """生成报告文件"""
        try:
            # 解析收集器的输出（简化版，实际中需要更复杂的解析）
            today = datetime.now().strftime("%Y-%m-%d")
            
            # 生成Markdown报告
            md_report = self.generate_markdown_report(today, paper_data)
            md_path = self.output_dir / f"paper_daily_{today}.md"
            
            with open(md_path, 'w', encoding='utf-8') as f:
                f.write(md_report)
            
            self.log_message(f"Markdown报告已生成: {md_path}")
            
            # 这里可以添加生成飞书文档的逻辑
            # self.generate_feishu_document(today, paper_data)
            
        except Exception as e:
            self.log_message(f"生成报告失败: {e}")
    
    def generate_markdown_report(self, date: str, paper_data: str) -> str:
        """生成Markdown格式的报告"""
        report = f"""# 📚 每日论文日报 - {date}

⏰ 生成时间: {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}
📊 收集状态: 完成

---

## 🔍 今日精选论文

{paper_data}

---

## 📋 使用说明

1. **论文来源**: 主要来自arXiv等国际学术平台
2. **筛选标准**: 前一天最新发布的论文
3. **涵盖领域**: 人工智能、机器学习、计算机科学、数据科学等
4. **推送时间**: 每天上午9:00自动推送

---

## 🔧 技术特点

- ✅ 自动收集前一天的论文
- ✅ 智能提取核心要点
- ✅ 大白话解释技术内容
- ✅ 支持多平台论文源
- ✅ 定时自动推送

---

> 🤖 本报告由「每日论文智能体」自动生成
> 📅 下次推送时间: 明天 09:00
"""
        return report
    
    def setup_schedule(self):
        """设置定时任务"""
        # 每天9:00执行
        schedule.every().day.at("09:00").do(self.run_daily_collection)
        
        # 立即执行一次（测试用）
        schedule.every(1).minutes.do(self.run_daily_collection)
        
        self.log_message("定时任务已设置：每天09:00执行论文收集")
        self.log_message("注意：测试模式下每分钟执行一次")
    
    def run(self):
        """运行调度器"""
        self.log_message("论文日报调度器启动")
        self.setup_schedule()
        
        try:
            while True:
                schedule.run_pending()
                time.sleep(60)  # 每分钟检查一次
        except KeyboardInterrupt:
            self.log_message("调度器已停止")
        except Exception as e:
            self.log_message(f"调度器异常退出: {e}")


def main():
    """主函数"""
    scheduler = PaperDailyScheduler(output_dir="./daily_paper_reports")
    scheduler.run()


if __name__ == "__main__":
    main()