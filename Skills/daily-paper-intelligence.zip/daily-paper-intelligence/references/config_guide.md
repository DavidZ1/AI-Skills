# 每日论文智能体配置指南

## 📋 配置文件说明

### 1. 领域配置
智能体支持多个学术领域，可以根据需要调整：

```python
# 支持的arXiv分类
domains = [
    'cs.AI',      # 人工智能
    'cs.LG',      # 机器学习
    'cs.CV',      # 计算机视觉
    'cs.CL',      # 计算语言学
    'cs.NE',      # 神经网络
    'cs.SE',      # 软件工程
    'cs.PL',      # 编程语言
    'cs.DB',      # 数据库
    'cs.CR',      # 密码学与安全
    'cs.DC',      # 分布式计算
    'stat.ML',    # 统计机器学习
    'q-bio',      # 定量生物学
    'physics',    # 物理学
    'math',       # 数学
    'eess',       # 电气工程与系统科学
]
```

### 2. 论文源配置
支持多个论文平台：

| 平台 | 状态 | 说明 |
|------|------|------|
| arXiv | ✅ 已实现 | 计算机科学、物理、数学等 |
| PubMed | 🔄 开发中 | 生物医学论文 |
| IEEE Xplore | 🔄 开发中 | 电气工程、计算机 |
| ACM Digital Library | 🔄 开发中 | 计算机科学 |

### 3. 输出配置

#### 3.1 Markdown输出
默认生成Markdown文件，包含：
- 论文标题和链接
- 作者信息
- 核心要点
- 大白话解释
- 实际意义

#### 3.2 飞书文档输出
需要配置飞书API：
```python
FEISHU_APP_ID = "your_app_id"
FEISHU_APP_SECRET = "your_app_secret"
```

### 4. 定时任务配置
```python
# 执行时间
schedule_time = "09:00"  # 每天9点

# 执行频率
schedule_interval = "daily"  # 每天一次

# 错误重试
max_retries = 3
retry_delay = 300  # 5分钟
```

## 🚀 快速开始

### 1. 安装依赖
```bash
pip install requests schedule
```

### 2. 运行测试
```bash
python scripts/paper_collector.py
```

### 3. 启动调度器
```bash
python scripts/daily_scheduler.py
```

### 4. 手动运行一次
```bash
python scripts/manual_run.py --date 2025-03-05 --count 5
```

## 🔧 高级配置

### 1. 自定义领域
编辑 `paper_collector.py` 中的 `domains` 列表，只保留感兴趣的领域。

### 2. 调整论文数量
```python
# 每天收集的论文数量
DAILY_PAPER_COUNT = 5  # 默认5篇

# 最小质量阈值
MIN_SCORE = 0.7  # 论文质量评分阈值
```

### 3. 通知设置
```python
# 邮件通知
EMAIL_ENABLED = True
EMAIL_RECIPIENTS = ["user@example.com"]

# 飞书机器人通知
FEISHU_BOT_ENABLED = True
FEISHU_WEBHOOK = "your_webhook_url"
```

### 4. 缓存配置
```python
# 避免重复推送
CACHE_ENABLED = True
CACHE_EXPIRY = 24  # 小时

# 黑名单（避免推送特定作者或机构的论文）
BLACKLIST_AUTHORS = []
BLACKLIST_INSTITUTIONS = []
```

## 📊 监控与日志

### 1. 日志级别
```python
LOG_LEVEL = "INFO"  # DEBUG, INFO, WARNING, ERROR
LOG_FILE = "./logs/paper_daily.log"
```

### 2. 性能监控
- 收集时间统计
- 论文质量评分
- 用户阅读率（如果集成飞书）

### 3. 错误处理
- 网络错误自动重试
- API限流处理
- 数据格式验证

## 🔄 更新与维护

### 1. 定期更新
- arXiv API可能会变化，需要定期检查
- 分类系统可能更新
- 新的论文源需要集成

### 2. 数据备份
```bash
# 备份历史数据
tar -czf paper_backup_$(date +%Y%m%d).tar.gz ./output/
```

### 3. 性能优化
- 使用缓存减少API调用
- 并行处理多个领域
- 增量更新避免重复工作

## 🤝 贡献指南

欢迎提交：
1. 新的论文源支持
2. 更好的摘要算法
3. 更多输出格式
4. Bug修复

## 📞 技术支持

遇到问题请检查：
1. 网络连接是否正常
2. API密钥是否有效
3. 日志文件中的错误信息
4. 依赖包版本是否兼容